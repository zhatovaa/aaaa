document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("pop_up").style.display = "flex";
});

document.getElementById("close").addEventListener("click", () => {
    document.getElementById("pop_up").style.display = "none";
})